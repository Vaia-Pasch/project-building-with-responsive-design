const removeFromArray = function() {
 
 }
  

module.exports = removeFromArray
