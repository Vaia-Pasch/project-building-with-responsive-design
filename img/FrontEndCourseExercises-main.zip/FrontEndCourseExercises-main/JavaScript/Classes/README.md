![](README.jpg)

# ORGANIZING YOUR JAVASCRIPT CODE | CLASSES

[**Submission Instructions (Ctrl+Click to open in a new Tab)**](https://github.com/SocialHackersAcademy/FrontEndCourseExercises/#instructions)

#### INSTRUCTIONS

Go back to your ["Library"](https://athena.socialhackersacademy.org/topic/project-library/) example and refactor it to use class instead of plain constructors.

[Project page](https://athena.socialhackersacademy.org/topic/classes/)

---

_Photo by Christina Morillo from Pexels_