![](README.jpg)

# ORGANIZING YOUR JAVASCRIPT CODE | CLASSES

[**Submission Instructions (Ctrl+Click to open in a new Tab)**](https://github.com/SocialHackersAcademy/FrontEndCourseExercises/#instructions)

#### INSTRUCTIONS

[Project page](https://athena.socialhackersacademy.org/topic/project-weather-app/)

---

_Photo by Andre Furtado from Pexels_
