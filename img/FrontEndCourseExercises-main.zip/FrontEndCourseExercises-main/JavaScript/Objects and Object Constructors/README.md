![](README.jpg)

# ORGANIZING YOUR JAVASCRIPT CODE | CLASSES

[**Submission Instructions (Ctrl+Click to open in a new Tab)**](https://github.com/SocialHackersAcademy/FrontEndCourseExercises/#instructions)

#### INSTRUCTIONS

[Project page](https://athena.socialhackersacademy.org/topic/objects-and-object-constructors/)

---

_Photo by Ivan Samkov from Pexels_

