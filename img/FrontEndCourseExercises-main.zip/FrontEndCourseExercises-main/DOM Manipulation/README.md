# WEB 101: JAVASCRIPT BASICS | DOM MANIPULATION

[**Submission Instructions (Ctrl+Click to open in a new Tab)**](https://github.com/SocialHackersAcademy/FrontEndCourseExercises/#instructions)


- [Topic: DOM Manipulation](https://athena.socialhackersacademy.org/topic/dom-manipulation/)
- [Quiz Page](https://athena.socialhackersacademy.org/quizzes/quiz-dom-manipulation/)

