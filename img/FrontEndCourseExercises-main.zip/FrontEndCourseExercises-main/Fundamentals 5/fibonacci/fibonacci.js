const fibonacci = function() {

}

module.exports = fibonacci
