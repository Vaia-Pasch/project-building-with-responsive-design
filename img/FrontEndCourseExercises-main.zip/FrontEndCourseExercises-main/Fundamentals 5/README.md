![](README.jpg)

# WEB 101: JAVASCRIPT FUNDAMENTALS 5

[**Submission Instructions (Ctrl+Click to open in a new Tab)**](https://github.com/SocialHackersAcademy/FrontEndCourseExercises/#instructions)

### INSTRUCTIONS

Complete the following exercises found on this repository:

- calculator
- palindromes
- caesar
- fibonacci
- getTheTitles
- findTheOldest

You can go through the [next video](https://www.youtube.com/watch?v=01glv9nr200) to see how you can set up and run the exercises.

[Project Page](https://athena.socialhackersacademy.org/topic/fundamentals-part-5/)

---

_Photo by JESHOOTS.com from Pexels_
