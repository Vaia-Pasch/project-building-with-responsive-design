[**Submission Instructions (Ctrl+Click to open in a new Tab)**](https://github.com/SocialHackersAcademy/FrontEndCourseExercises/#instructions)

#### INSTRUCTIONS

- 1) Enter a name in the input field and press the submit button. You will see that although the name is added to the list, it is appended to the list along with the rest of the names that were previously there. Your first task is to resolve this issue, so that only the name entered gets appended to the list upon clicking the submit button. 

- 2) Add two more input fields for surname and age that will get appended to the list along with the name every time the submit button is clicked.

The source code can be found in the `index.html` and `user_management.js` files.